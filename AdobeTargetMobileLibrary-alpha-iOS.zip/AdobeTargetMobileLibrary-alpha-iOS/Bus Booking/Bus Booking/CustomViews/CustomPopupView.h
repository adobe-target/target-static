//
//  CustomPopupView.h
//  TargetMobileTester
//
//  Created by Anil Bunkar on 29/06/18.
//  Copyright © 2018 adobe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomPopupView : UIView
@property (nonatomic, strong) IBOutlet UIView *contentView;

@end
