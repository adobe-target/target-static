# Installation instructions

## How to build the Alpha Package

1. In this sub-directory run the following command:
	```bash
	make release
	```
2.  Grab the .zip file that is placed in *bin/* subdirectory at the project root.
3.  Otherwise, this document should be placed inside the zip file automatically.

## Grab your XCode application code

1.  Open up your favoriate application in XCode **OR** use the example application
 for your test application
	```
	git clone https://github.com/adobe-target/mobile-lab.git
	```
## Put Target Mobile iOS Extension Library in your App project
1.  Download the package and unzip the package and place the *AdobeTargetMobileLibrary*
subdirectory into the same directory where you put the source code.

## Change to the App Project Settings to integate Mobile VEC

1.  Open your application project in XCode
2.  Add the embedded libraries:
	1.  Click on your application project settings -> General -> Embedded binaries,
		click on the Plus Sign and "Add Other..." button on the pop-up dialog
	2.  Navigate to the AdobeTargetMobileLibrary-alpha2-iOS unzipped directory
	3.  Go to the subdirectory AdobeTargetMobileLibrary
	4.  Select the two (2) files:
	```
	SocketRocket.framework
	SocketCluster_ios_client.framework
	```
	5.  Press "Open" button.
	6.  In the following dialog, "Choose options for adding these files", be sure to click on "Copy items if needed" and
	click on the Finish button.
4.  Add the ADBAdobeTargetMobile.h include file to your project
	1.  Right click the subdirectory where your source code and/or where AppDelegate.m resides
	2.  Select "Add files to <Usually application name>..."
	3.  Navigate to the AdobeTargetMobileLibrary-alpha2-iOS unzipped directory
	4.  Go to the subdirectory AdobeTargetMobileLibrary
	4.  Select the file: ADBAdobeTargetMobile.h
	5.  Press "Open" button.
	6.  In the following dialog, "Choose options for adding these files", be sure to click on "Copy items if needed" and
	click on the Finish button.
5.  Add the required iOS system libraries (if not already present in your project):
	1.  Click on your application project settings -> General -> Linked Frameworks and Libraries
		click on the Plus Sign
	2.  Select the system framework by searching for the following libraries, selecting them and pressing the Add button.
	Repeat the steps 1 and 2 for each of the other frameworks and C++ library
	```
	UIKit.framework
	WebKit.framework
	UserNotifications.framework
	libstdc++.tbd
	```
	3.  Select the framework by searching for the following libraries, selecting them and pressing the Add button.
		click on the Plus Sign and "Add Other..." button on the pop-up dialog
	2.  Navigate to the AdobeTargetMobileLibrary-alpha2-iOS unzipped directory
	3.  Go to the subdirectory AdobeTargetMobileLibrary
	4.  Select the one(1) file:
	```
	AdobeTargetMobileLibrary_iOS.a
	```
6.  Change build settings for Mobile VEC
	1.  Click on your application project settings -> Build Settings
	2.  In the search dialog, search for "Other Linker Flags"
	3.  In the column under your application, add the following string to the current linker options:
	```
	-all_load -ObjC
	```
	4.  Make sure that you've copied the string exactly as above
6.  Add Framework Search Path for Mobile VEC
	2.  In the search dialog, search for "Framework Search Paths"
	3.  Double-click on the Framework Search Paths entry under the Application
	4.  Press the Plus sign and add an entry with the directory of location of the unzipped AdobeTargetMobileLibrary
7.  Add the deeplink handler:
	1.  Click on your application project settings -> Info
	2.  Under "URL Types", press the triagle to open it up and then click on the Plus Sign to add a new field
	3.  Add the the following information:
		Identifier: com.adobe.sdktest
		URL Schemes: vectester
		Role: Editor
	4.  Click away on your application project settings -> General
	4.  Click back on your application project settings -> Info to make sure your settings were saved.
	5.  **N.B.** The URL scheme for your app will be:
	```
	vectester://com.adobe.sdktest
	```
## Required Code Changes for your project

1. In XCode, open your AppDelegate.m file.
2. Add the top of the file, add the following line at the end of your imports:
	```
	#import "ADBAdobeTargetMobile.h"
	```
1. Get the following information from your SDK integration values.   If you
do NOT know of these values, please talk directly with your customer
representative.
	1. Target Client Code
	1. Marketing Cloud Organization Id
2. Add the following line to your AppDelegate::application:didFinishLaunchingWithOptions:. If the delegate function is
not defined, create it and add the line.
	```
	[ADBAdobeTargetMobile SDKV5_SHIM_initShimWithClientCode:@"targetpremiumqa2"
										 withMarketingOrgId:@"ExampleOrgID"
								withAuthoringClusterUrlBase:TARGET_AUTHORING_URL_CLUSTER_US];
	```
	As a example, the method should finally look this:
	```
	- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
		// Override point for customization after application launch.

[ADBMobile collectLifecycleData];
		[ADBMobile setDebugLogging:YES];

		[ADBAdobeTargetMobile SDKV5_SHIM_initShimWithClientCode:@"targetpremiumqa2"
			withMarketingOrgId:@"ExampleOrgID"
								withAuthoringClusterUrlBase:TARGET_AUTHORING_URL_CLUSTER_US];
		return YES;
	}
	```
	```
	[ADBAdobeTargetMobile SDKV5_SHIM_initShimWithClientCode:@"targetpremiumqa2"
										 withMarketingOrgId:@"039E5CD253BE29E30A4C86E6@AdobeOrg"
								withAuthoringClusterUrlBase:@"ws://sj1010010254027.corp.adobe.com:8080"];
	```
3. Add the following line to your AppDelegate::applicationWillResignActive.  If the delegate function is
not defined, create it and add the following line.
	```
	[ADBAdobeTargetMobile SDKV5_SHIM_applicationWillResignActive:application];

	```
	As a example, the method should finally look this:
	```
	- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
		// Override point for customization after application launch.

		[ADBMobile collectLifecycleData];
		[ADBMobile setDebugLogging:YES];

		[ADBAdobeTargetMobile SDKV5_SHIM_initShim];
		return YES;
	}
	```
4. Add the following line to your AppDelegate::applicationDidBecomeActive.  If the delegate function is
not defined, create it and add the following line.
	```
	[ADBAdobeTargetMobile SDKV5_SHIM_applicationWillResignActive:application];

	```
	As a example, the method should finally look this:
	```
	- (void)applicationDidBecomeActive:(UIApplication *)application {
		// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
		[ADBAdobeTargetMobile SDKV5_SHIM_applicationDidBecomeActive:application];
	}
	```
5. Add the following line to the beginning of AppDelegate:application:openURL.  If the delegate function is
not defined, create it and add the following line.
	```
	[ADBAdobeTargetMobile SDKV5_SHIM_handleDeepLink:url];
	```

	```
	- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<NSString *, id> *)options {
		[ADBAdobeTargetMobile SDKV5_SHIM_handleDeepLink:url];
		return YES;
	}
	```
}

## Running the application in Mobile VEC

Your app is now ready to run with Mobile VEC.
